package com.pennant;

import java.util.Scanner;

public class Subscriber {

	int id;
	String name;
	String plan;
	double planCost;
	int duration;
	int noOfFreeMinutes;
	int noOfFreeSMS;
	String freeData;
	int noOfExtraMinutes;
	double costPerExtraMinute;
	int noOfExtraSMS;
	double costPerExtraSMS;
	int extraData;
	double costPerExtraData;
	int noOfRoamingCalls;
	double costPerRoamingCalls;
	long mobileNumber;
	String network;
	String location;

	public Subscriber(int id, String name, String plan, double planCost, int duration, int noOfFreeMinutes,
			int noOfFreeSMS, String freeData, int noOfExtraMinutes, double costPerExtraMinute, int noOfExtraSMS,
			double costPerExtraSMS, int extraData, double costPerExtraData, int noOfRoamingCalls,
			double costPerRoamingCalls, long mobileNumber, String network, String location) {
		this.id = id;
		this.name = name;
		this.plan = plan;
		this.planCost = planCost;
		this.duration = duration;
		this.noOfFreeMinutes = noOfFreeMinutes;
		this.noOfFreeSMS = noOfFreeSMS;
		this.freeData = freeData;
		this.noOfExtraMinutes = noOfExtraMinutes;
		this.costPerExtraMinute = costPerExtraMinute;
		this.noOfExtraSMS = noOfExtraSMS;
		this.costPerExtraSMS = costPerExtraSMS;
		this.extraData = extraData;
		this.costPerExtraData = costPerExtraData;
		this.noOfRoamingCalls = noOfRoamingCalls;
		this.costPerRoamingCalls = costPerRoamingCalls;
		this.mobileNumber = mobileNumber;
		this.network = network;
		this.location = location;
	}

	public Subscriber(int id, String name, String plan, double planCost, long mobileNumber, String network,
			String location) {
		super();
		this.id = id;
		this.name = name;
		this.plan = plan;
		this.planCost = planCost;
		this.mobileNumber = mobileNumber;
		this.network = network;
		this.location = location;
	}

	public void getDetails() {

		System.out.println("--------------Customer Details-------------------");

		System.out.println("Subscriber id: " + id);
		System.out.println("Subscriber Name: " + name);
		System.out.println("Mobile number: " + mobileNumber);
		System.out.println("Network: " + network);
		System.out.println("Location: " + location);

		System.out.println("Subscriber plan: " + plan);
		System.out.println("Subscriber cost of plan: " + planCost);
		System.out.println("Subscriber duration of plan: " + duration);
		System.out.println("Free Minutes: " + noOfFreeMinutes);
		System.out.println("Free SMS: " + noOfFreeSMS);
		System.out.println("Free Data: " + freeData);
		System.out.println("Extra Minutes: " + noOfExtraMinutes);
		System.out.println("Cost per extra minute: " + costPerExtraMinute);
		System.out.println("Extra SMS: " + noOfExtraSMS);
		System.out.println("Cost per extra sms: " + costPerExtraSMS);
		System.out.println("Extra Data: " + extraData);
		System.out.println("Cost per extra data: " + costPerExtraData);
		System.out.println("Roaming calls: " + noOfRoamingCalls);
		System.out.println("Cost per roaming call: " + costPerRoamingCalls);

	}

	public void getPersonalDetailsForHr() {
		System.out.println("-------------Customer Details--------------");
		System.out.println("Subscriber id: " + id);
		System.out.println("Subscriber Name: " + name);
		System.out.println("Mobile number: " + mobileNumber);
		System.out.println("Network: " + network);
		System.out.println("Location: " + location);

	}

	public double generateBill() {
		double bill;
		double gstTax = 25.98;
		double discount = 10 % 100;
		bill = planCost + (costPerExtraMinute * noOfExtraMinutes) + (costPerExtraSMS * noOfExtraSMS)
				+ (costPerExtraData * extraData) + (noOfRoamingCalls * costPerRoamingCalls) + gstTax - discount;
		return bill;

	}

	public static double generateTurnOver(Subscriber subscriber[]) {
		double totalBill = 0;
		for (int i = 0; i < subscriber.length; i++) {
			totalBill = totalBill + subscriber[i].generateBill();
		}
		return totalBill;

	}

	public static void main(String[] args) {
		Subscriber[] subscriber = new Subscriber[3];
		subscriber[0] = new Subscriber(30, "teja", "tariff-169", 169.25, 28, 100, 100, "1.0", 50, 2.5, 50, 1, 500, 25,
				50, 150.23, 8686734334l, "Airtel", "Hyderabad");
		subscriber[1] = new Subscriber(31, "tony", "tariff-125", 125.25, 28, 100, 100, "1.5", 50, 2.5, 50, 1, 500, 25,
				50, 150.23, 9502668278l, "Airtel", "Hyderabad");
		subscriber[2] = new Subscriber(32, "bruce", "tariff-199", 199.25, 30, 100, 100, "2.5", 50, 2.5, 50, 1, 500, 25,
				50, 150.23, 8885850020l, "Airtel", "Hyderabad");

		System.out.println("1.Customer\t2.HR\t3.Management\t4.exit");
		Scanner scanner = new Scanner(System.in);
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			System.out.println("Enter Your Id:");
			int id = scanner.nextInt();
			for (int i = 0; i < subscriber.length; i++) {
				if (id == subscriber[i].id) {
					subscriber[i].getDetails();
					double bill = subscriber[i].generateBill();
					System.out.println("Bill: " + bill);
				}
			}
			break;
		case 2:
			for (int i = 0; i < subscriber.length; i++) {
				Subscriber hr = new Subscriber(subscriber[i].id, subscriber[i].name, subscriber[i].plan,
						subscriber[i].planCost, subscriber[i].mobileNumber, subscriber[i].network,
						subscriber[i].location);

				hr.getPersonalDetailsForHr();
			}
			break;
		case 3:
			double finalBill = generateTurnOver(subscriber);
			System.out.println("Turn Over of the company : " + finalBill);
			break;
		case 4:
			System.exit(choice);
			break;
		default:
			System.err.println("Please enter valid option");
			break;
		}
		scanner.close();
	}

}
